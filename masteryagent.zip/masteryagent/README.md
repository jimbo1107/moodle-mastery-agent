# Mastery agent (mod_masteryagent)

A Moodle activity that assesses a learner through a bounded conversation
instead of a multiple-choice quiz.

Built for the MCU-NPS AI Learning Initiatives use case *PME Course Material
Mastery Evaluation Agent* (EWSDEP 8670 prerequisite course).

## What it does

1. A teacher uploads the course question-set JSON and names which lessons this
   activity assesses — one, a few, or all of them.
2. The agent puts the first lesson's question to the learner.
3. Each reply is judged against that lesson's evidence rubric. The agent tracks
   which strong-evidence elements have been demonstrated and which
   misconceptions have appeared, then probes the largest remaining gap — one
   question at a time.
4. A lesson closes when its evidence is complete or its reply budget is spent.
   The agent says so and puts the next lesson's question straight away; the
   learner never has to navigate anywhere.
5. After the last lesson the agent reports a score and written feedback for
   every lesson, adds an overall judgement across the whole run, and pushes the
   total to the gradebook.

A learner can stop part way and come back: the attempt keeps its place, and
lessons never reached simply score nothing.

## Requirements

- Moodle 4.5 or later (5.1 recommended; developed and tested against 5.1.7).
- An AI provider configured in **Site administration → General → AI → AI
  providers**, with the **Generate text** action enabled.

All model access goes through `\core_ai\manager`, so the site's API key, rate
limits, AI user policy and `ai_action_register` logging apply to every request
this plugin makes. The plugin stores no credentials of its own.

## Installation

Upload the zip at **Site administration → Plugins → Install plugins**, or
extract into `mod/masteryagent` (`public/mod/masteryagent` when your Moodle installation uses a `public` web root).

## AJAX conversation (0.4.0)

Beginning an assessment, sending a reply, ending and scoring, and starting a
new attempt now update the conversation in place. There is no AJAX setting to
toggle. JavaScript-enabled browsers automatically use Moodle's `core/ajax`
service; normal POST forms remain available if JavaScript is unavailable.

The page shows a processing status, prevents concurrent submissions, moves
focus to the reply box or final result, and preserves draft text after errors.
Stale requests from another tab or after a lost response refresh the conversation
without applying the action again. Review the displayed conversation before
resubmitting a preserved draft.

The service validates the module context, enrolment/access and capabilities,
uses the signed-in user's latest attempt, and returns only the learner-facing
HTML. A per-user/activity lock serializes updates. Conversation actions use a
DB transaction so provider or scoring failures do not save a partial turn or
grade. External provider requests themselves cannot be rolled back.

### Upgrading from 0.3.2

1. Install the new ZIP through **Site administration → Plugins → Install plugins**,
   or replace the existing `mod/masteryagent` directory under your Moodle web root.
2. Visit **Site administration → Notifications** and complete the plugin upgrade.
   Version `2026091703` registers `mod_masteryagent_update_conversation` from
   `db/services.php`. Copying the files alone does not register this service.
3. Purge Moodle caches using **Site administration → Development → Purge caches**.
4. Open an activity as an enrolled learner and begin, reply, finish, and retry
   if allowed. The conversation and scores should update without a new page load.

The built JavaScript and source map are included in `amd/build`; no build tool
is required for installation. There is no need to enable general external web
services, create a token, or change the existing AI-provider settings. In a
Moodle development checkout, rebuild edited JavaScript with `npx grunt amd`
from the plugin directory.

Implementation references:
[Moodle AJAX](https://moodledev.io/docs/5.1/guides/javascript/ajax),
[external service definitions](https://moodledev.io/docs/5.1/apis/subsystems/external/writing-a-service),
[external API security](https://moodledev.io/docs/5.1/apis/subsystems/external/security),
and [the Lock API](https://moodledev.io/docs/5.1/apis/core/lock).

## Settings

| Setting | Default | Notes |
| --- | --- | --- |
| Question set file | — | The course JSON. May contain every lesson. |
| Lessons to assess | — | Comma separated lesson or question IDs, in the order to run them. Blank means every lesson in the file. |
| Maximum replies per lesson | 6 | Hard ceiling per lesson. The agent may close one sooner. |
| Maximum score per lesson | 4 | Gradebook maximum is this times the number of lessons. |
| Mastery threshold per lesson | 3 | Score at or above which a lesson counts as mastered. |
| Allow repeat attempts | Yes | Gradebook keeps the highest total. |
| Mark grades as AI-provisional | Yes | Flags released grades as awaiting SME validation. |

## Choosing a structure

Both shapes work; pick per course.

**One activity per lesson** (`L01` in one activity, `L02` in the next) gives a
gradebook column per lesson, lets you release lessons as the course progresses,
and matches a lesson → reading → assessment rhythm.

**One activity for several lessons** (`L01,L02,L03`, or blank for all thirteen)
runs as a single sitting with automatic progression, one gradebook column
holding the total, and a course-level judgement at the end. This is the closer
fit for an end-of-course mastery interview.

## Updating the questions

Re-upload a newer question-set file on an existing activity and it picks up the
revised questions and rubrics. Nothing else changes and existing attempts are
left alone. This is the intended path for keeping the assessment current as
lessons and educational objectives are revised.

## What the learner never sees

The evidence guide, misconception list and insufficient-evidence conditions are
sent to the model and shown to anyone with `mod/masteryagent:viewreports`. They
are never rendered to a learner, and the agent is instructed not to restate
them or answer the question on the learner's behalf.

## Instructor report

**View attempts** lists every attempt with its total, how many lessons closed,
and its status. Opening one shows the per-lesson score table, the full
transcript, the evidence ledger the agent maintained, and the rubric behind
every lesson — which is what a subject matter expert needs in order to validate
or overturn the agent's judgement.

## Tests

`tests/` holds 86 PHPUnit tests covering the parser, lesson selection, prompt
construction, the conversation engine, gradebook, and AJAX access and recovery.
The 15 AJAX regression tests are new in 0.4.0. They have been added but have not
been executed in the packaging environment, which has no Moodle/PHP runtime.
No AI provider is called by the tests. See `tests/README.md` for setup, browser
tests, and the suite command.

## Known limitations

- **No backup/restore support.** `FEATURE_BACKUP_MOODLE2` is declared false, so
  these activities are skipped by course backup rather than silently corrupting
  one. This is the first thing to add for production use.
- **No Moodle Mobile app integration.** The browser uses an authenticated AJAX
  service, but the plugin does not provide a Moodle Mobile interface.
- **Synchronous model calls on the server.** AJAX keeps the browser page in
  place while the provider works; it does not stream tokens or queue background
  jobs. Failed requests are not automatically replayed. Learners may retry
  manually, with the displayed revision checked to prevent duplicate turns.
- **Rubrics are agent-generated drafts.** The supplied question set is marked
  `DRAFT_PENDING_HUMAN_VALIDATION`. Keep the AI-provisional flag on until an SME
  has validated the rubric.

## Licence

GPL v3 or later, matching Moodle.
