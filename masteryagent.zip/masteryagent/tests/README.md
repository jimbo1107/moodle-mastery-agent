# Running the mastery agent tests

67 PHPUnit tests covering the question-set parser, lesson selection, prompt
construction, the conversation engine, and the gradebook. They never call a real
AI provider — a scripted responder stands in for one — so they cost nothing to
run and are deterministic.

## One-time setup on a dev Moodle

From the Moodle root (not the plugin directory):

```bash
composer install
# add to config.php, above require_once(__DIR__ . '/lib/setup.php'):
#   $CFG->phpunit_prefix = 'phpu_';
#   $CFG->phpunit_dataroot = '/path/to/phpunitdata';
php admin/tool/phpunit/cli/init.php
```

On Moodle 5.0+ the CLI scripts live outside the web root, so the last command is
`php public/admin/tool/phpunit/cli/init.php` if that path is what exists.

Re-run `init.php` after installing or upgrading any plugin — it rebuilds the
test database and the suite list.

## Running them

```bash
# just this plugin
vendor/bin/phpunit --testsuite mod_masteryagent_testsuite

# one file
vendor/bin/phpunit public/mod/masteryagent/tests/attempt_test.php

# one test
vendor/bin/phpunit --filter test_a_sequence_advances_on_its_own
```

Expected: `OK (67 tests, 197 assertions)`.

## What each file covers

| File | Covers |
| --- | --- |
| `lesson_test.php` | Reading a question set: wrapper and bare-array forms, missing fields, source metadata |
| `sequence_test.php` | Lesson selection by id, ordering, unknown ids, legacy single-lesson instances |
| `agent_test.php` | Prompt contents, JSON parsing (fenced, prose-wrapped, malformed), score clamping, course summary |
| `attempt_test.php` | Turns, budget exhaustion, automatic lesson advance, totals, early finish, provider failure recovery |
| `lib_test.php` | Settings form save paths, file upload and re-upload, gradebook item and grade writing, deletion cleanup |

## After you change something

Run the suite. If a test fails, read the failure message before the code — the
assertions carry messages explaining what behaviour is being protected, e.g.
"a weaker retake does not lower the grade".

If you change behaviour deliberately, update the test in the same commit. A test
that no longer matches the intended behaviour should be changed, not deleted.

## Adding a test

Activities come from the generator, so a new test starts in two lines:

```php
$course = $this->getDataGenerator()->create_course();
$instance = $this->getDataGenerator()->create_module('masteryagent', [
    'course' => $course->id,
    'lessonkeys' => 'S01,S02',   // from tests/fixtures/sample_question_set.json
]);
```

Then script the AI with `$this->stub_ai([...])` from `helper_trait.php`:

```php
$this->stub_ai([
    'closeafter' => 2,                  // close each lesson after 2 replies
    'scores' => ['S01' => 4, 'S02' => 2],
    'reply' => 'What would you check yourself?',
]);
```

Always call `$this->reset_ai()` in `tearDown()` so the stub does not leak into
the next test.

The fixture is synthetic content written for these tests — three invented
lessons (S01–S03). It is not course material, and tests should assert against it
rather than against any real question set.
